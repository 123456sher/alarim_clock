enum MenuType {alarm}
